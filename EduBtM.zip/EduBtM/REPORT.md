# EduBtM Report

Name: Nguyen Duong Tung  
Student ID: 49004034

## Problem Analysis

The problem at hand is to implement the operations of the B+ tree index and the related index page structure in EduBtM. The goal is to handle a limited subset of the original ODYSSEUS/COSMOS BtM functionality. The specific functions that need to be implemented are as follows:

1. EduBtM_CreateIndex(): This function is responsible for creating a new B+ tree index.

2. EduBtM_DropIndex(): This function is used to drop an existing B+ tree index.

3. EduBtM_InsertObject(): It inserts a new object into the B+ tree index.

4. EduBtM_DeleteObject() (optional): This function allows for the deletion of an object from the B+ tree index.

5. EduBtM_Fetch(): It retrieves a specific object from the B+ tree index.

6. EduBtM_FetchNext(): This function fetches the next object in the B+ tree index.

In addition to these functions, several internal smaller functions need to be implemented. These include:

- edubtm_InitLeaf(): Initializes a leaf page of the B+ tree index.
- edubtm_InitInternal(): Initializes an internal page of the B+ tree index.
- edubtm_FreePages(): Frees the allocated pages of the B+ tree index.
- edubtm_Insert(): Inserts an object into the B+ tree index.
- edubtm_InsertLeaf(): Inserts an object into a leaf page of the B+ tree index.
- edubtm_InsertInternal(): Inserts an object into an internal page of the B+ tree index.
- edubtm_SplitLeaf(): Splits a leaf page during insertion.
- edubtm_SplitInternal(): Splits an internal page during insertion.
- edubtm_root_insert(): Handles the insertion into the root page of the B+ tree index.
- edubtm_Delete(): Deletes an object from the B+ tree index.
- edubtm_DeleteLeaf(): Deletes an object from a leaf page of the B+ tree index.
- edubtm_CompactLeafPage(): Performs leaf page compaction after deletion.
- edubtm_CompactInternalPage(): Performs internal page compaction after deletion.
- edubtm_Fetch(): Fetches a specific object from a given page of the B+ tree index.
- edubtm_FetchNext(): Fetches the next object from a given page of the B+ tree index.
- edubtm_FirstObject(): Retrieves the first object from a given page of the B+ tree index.
- edubtm_LastObject(): Retrieves the last object from a given page of the B+ tree index.
- edubtm_BinarySearchLeaf(): Performs a binary search for a specific object in a leaf page.
- edubtm_BinarySearchInternal(): Performs a binary search for a specific object in an internal page.
- edubtm_KeyCompare(): Compares two keys in the B+ tree index.

## Design For Problem Solving

### High-Level Design

At a high level, the design for solving the problem involves implementing the required B+ tree index operations and the related index page structures. The B+ tree index is a balanced tree structure with internal nodes and leaf nodes. The tree structure allows for efficient searching, insertion, deletion, and fetching of objects based on their keys.

The high-level design should include the following components:

1. B+ Tree Index Creation: Implement the EduBtM_CreateIndex() function to create a new B+ tree index. This involves initializing the root node and allocating necessary pages.

2. B+ Tree Index Deletion: Implement the EduBtM_DropIndex() function to drop an existing B+ tree index. This includes freeing the allocated pages and releasing any associated resources.

3. Object Insertion: Implement the EduBtM_InsertObject() function to insert a new object into the B+ tree index. This requires handling the insertion process and splitting of pages if necessary.

4. Object Deletion (Optional): If applicable, implement the EduBtM_DeleteObject() function to delete an object from the B+ tree index. This involves handling the deletion process and performing page compaction if necessary.

5. Object Retrieval: Implement the EduBtM_Fetch() function to retrieve a specific object from the B+ tree index. This requires searching the tree structure based on the object's key and returning the corresponding object.

6. Next Object Retrieval: Implement the EduBtM_FetchNext() function to fetch the next object in the B+ tree index. This involves traversing the tree structure and returning the next object in the sorted order.

### Low-Level Design (Code Level)

The low-level design focuses on the implementation details of each function and the internal functions to be implemented. It should include the following:

1. Initialization Functions: Implement the initialization functions, such as edubtm_InitLeaf() and edubtm_InitInternal(), to initialize leaf and internal pages, respectively. These functions should set up the necessary data structures and metadata for the pages.

2. Page Management: Implement the page management functions, such as edubtm_FreePages(), to handle the allocation and deallocation of pages in the B+ tree index. These functions should manage the usage of pages efficiently.

3. Insertion Functions: Implement the insertion functions, such as edubtm_Insert(), edubtm_InsertLeaf(), edubtm_InsertInternal(), edubtm_SplitLeaf(), and edubtm_SplitInternal(), to handle the insertion of objects into the B+ tree index. These functions should ensure the tree's balance and update the necessary metadata.

4. Root Insertion: Implement the edubtm_root_insert() function to handle the insertion of objects into the root page of the B+ tree index. This function should handle splitting the root page if necessary and updating the root pointer.

5. Deletion Functions (Optional): If applicable, implement the deletion functions, such as edubtm_Delete(), edubtm_DeleteLeaf(), edubtm_CompactLeafPage(), and edubtm_CompactInternalPage(), to handle the deletion of objects from the B+ tree index. These functions should maintain the tree's balance and update the metadata accordingly.

6. Fetching Functions: Implement the fetching functions, such as edubtm_Fetch(), edubtm_FetchNext(), edubtm_FirstObject(), and edubtm_LastObject(), to retrieve objects from the B+ tree index. These functions should perform the necessary searches and return the desired objects.

7. Binary Search Functions: Implement the binary search functions, such as edubtm_BinarySearchLeaf() and edubtm_BinarySearchInternal(), to perform efficient searches within leaf and internal pages, respectively. These functions should utilize binary search algorithms for faster retrieval.

8. Key Comparison Function: Implement the edubtm_KeyCompare() function to compare two keys in the B+ tree index. This function should provide the necessary comparison logic for proper ordering of objects.

## Mapping Between Implementation And the Design

The mapping between the high-level design and the low-level implementation involves implementing each function as described in the design phase. Each function should be implemented according to its defined purpose and follow the algorithms and data structures specific to the B+ tree index.

The implementation should ensure that the code correctly handles the creation, deletion, insertion, deletion (if applicable), and retrieval of objects in the B+ tree index. It should also consider the internal structure of the index pages, including the necessary metadata and the splitting/compaction mechanisms.

By following the design and mapping it to the implementation, the resulting code should provide a functional and efficient solution for the EduBtM project objectives.

Please note that the code implementation details is in the files.
